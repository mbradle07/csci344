import React from 'react';

export default function Suggestions() {
    return (
        <div className="suggestions">
            <div>
                Suggestions go here...
            </div>
        </div>
    );
}