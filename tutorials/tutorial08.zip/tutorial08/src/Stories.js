import React from 'react';

export default function Stories() {
    return (
        <header className="stories">
            Stories go here...
        </header>
    );
}